<?php
declare(strict_types=1);

use Core\Application;

define('ROOT_PATH', dirname(__DIR__));

require ROOT_PATH . '/vendor/autoload.php';
require ROOT_PATH . '/bootstrap.php';

$app = new Application();
$app->run();
