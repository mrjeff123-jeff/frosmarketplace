# Fro's Marketplace

Starter project for the Fro's Marketplace platform.

Current contents:
- public/index.php
- bootstrap.php
- core/Application.php

Next sprint:
- Router
- Request/Response
- Database
- Installer
- Authentication
