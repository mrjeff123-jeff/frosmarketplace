<?php
declare(strict_types=1);

session_start();

date_default_timezone_set('UTC');

error_reporting(E_ALL);
ini_set('display_errors', '1');

define('APP_NAME', "Fro's Marketplace");
define('APP_VERSION', '1.0.0-alpha');
