<?php
namespace Core;

class Application
{
    public function run(): void
    {
        echo "<h1>Welcome to Fro's Marketplace</h1>";
        echo "<p>Version 1.0.0-alpha</p>";
        echo "<p>The framework is running successfully.</p>";
    }
}
